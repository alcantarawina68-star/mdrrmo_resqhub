# API.md: ResQHub

## Authentication & Authorization

All endpoints except `POST /api/v1/auth/login` and `POST /api/v1/auth/register` require a Bearer token in the `Authorization` header:

```
Authorization: Bearer <JWT_TOKEN>
```

Tokens are issued by the Laravel backend using JWT (JSON Web Tokens) with a 24-hour expiry. Role-based access control (RBAC) is enforced server-side via middleware. Roles: `admin`, `encoder`, `barangay_official`, `responder`, `community_user`.

## Standard Response & Pagination Formats

**Success:** `{ "success": true, "data": { ... } }`

**Error:** `{ "success": false, "message": "Human-readable error", "errors": { "field": ["Validation message"] } }` with appropriate HTTP status code (400, 401, 403, 404, 422).

**Pagination:** Paginated responses return `data` as an array with a `meta` object: `{ "current_page": 1, "last_page": 5, "per_page": 20, "total": 97 }`.

## API Endpoints

### Auth & User Management

#### POST /api/v1/auth/login

Authenticates a user and returns a JWT token.

| Field | Type | Required | Description |
|---|---|---|---|
| `email` | string | Yes | Registered email address |
| `password` | string | Yes | User password |

**Auth level:** Public

**Request Body:**
```json
{
  "email": "juan.delacruz@example.com",
  "password": "securepass123"
}
```

**Response Body (200 OK):**
```json
{
  "success": true,
  "data": {
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "token_type": "bearer",
    "expires_in": 86400,
    "user": {
      "id": 1,
      "name": "Juan Dela Cruz",
      "email": "juan.delacruz@example.com",
      "role": "community_user"
    }
  }
}
```

**Status Codes:** `200` Success · `401` Invalid credentials · `422` Validation error

---

### Incident Reporting

#### POST /api/v1/incidents

Creates a new online incident report using the map-first flow. The location must be selected on the map before submission; `latitude` and `longitude` are captured from the map click.

| Field | Type | Required | Description |
|---|---|---|---|
| `latitude` | float | Yes | Latitude from map click (-90 to 90) |
| `longitude` | float | Yes | Longitude from map click (-180 to 180) |
| `incident_type` | string | Yes | One of: `typhoon_flood`, `earthquake`, `landslide`, `vehicular_accident`, `fire`, `drowning`, `hazmat`, `ems`, `patient_transport`, `other` |
| `description` | string | Yes | Narrative of the incident (min 20 chars) |
| `severity` | string | Yes | `low`, `medium`, `high`, `critical` |
| `evidence` | file[] | No | Up to 5 image/document files (max 10MB each, jpg/png/pdf) |
| `contact_number` | string | No | Callback number for updates |

**Auth level:** `community_user`, `encoder`, `admin`, `barangay_official`, `responder`

**Request Body (multipart/form-data):**
```json
{
  "latitude": 13.2712,
  "longitude": 123.4121,
  "incident_type": "typhoon_flood",
  "description": "Flooding along Camal riverside, water level rising rapidly near residential area.",
  "severity": "high",
  "contact_number": "09171234567",
  "evidence": ["file1.jpg", "file2.jpg"]
}
```

**Response Body (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": 1042,
    "incident_number": "RQ-2025-1042",
    "status": "under_verification",
    "source": "online",
    "latitude": 13.2712,
    "longitude": 123.4121,
    "incident_type": "typhoon_flood",
    "description": "Flooding along Camal riverside, water level rising rapidly near residential area.",
    "severity": "high",
    "reported_at": "2025-01-15T14:32:10+08:00",
    "reporter": { "id": 1, "name": "Juan Dela Cruz" }
  }
}
```

**Status Codes:** `201` Created · `400` Invalid coordinates · `401` Unauthenticated · `422` Validation error

---

### Verification & Status Management

#### PATCH /api/v1/incidents/{id}/verify

Manually verifies or rejects a pending incident. Only incidents with status `under_verification` can be processed. Verified incidents become visible on the public map.

| Field | Type | Required | Description |
|---|---|---|---|
| `action` | string | Yes | `approve` or `reject` |
| `status` | string | Yes | On approve: `verified`; on reject: `rejected` |
| `notes` | string | No | Internal review notes |
| `assigned_unit` | string | No | MDRRMO unit or responder ID to assign |

**Auth level:** `admin`, `encoder`

**Request Body:**
```json
{
  "action": "approve",
  "status": "verified",
  "notes": "Confirmed with barangay captain. Coordinates verified.",
  "assigned_unit": 7
}
```

**Response Body (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": 1042,
    "incident_number": "RQ-2025-1042",
    "status": "verified",
    "verified_at": "2025-01-15T14:45:02+08:00",
    "verified_by": { "id": 3, "name": "Maria Santos", "role": "encoder" },
    "assigned_unit": { "id": 7, "name": "Rescue Unit Alpha" },
    "public_visible": true
  }
}
```

**Status Codes:** `200` Success · `403` Forbidden (not encoder/admin) · `404` Incident not found · `409` Incident not in `under_verification` status

---

### Caller-Based Report Encoding

#### POST /api/v1/incidents/caller-based

Encodes a phone-call incident report received by MDRRMO personnel. This endpoint is only accessible to authorized staff and supports anonymous caller flagging.

| Field | Type | Required | Description |
|---|---|---|---|
| `caller_name` | string | No | Caller's full name (null if anonymous) |
| `caller_contact` | string | No | Caller's contact number (null if anonymous) |
| `is_anonymous` | boolean | Yes | Must be `true` if caller name/contact omitted |
| `latitude` | float | Yes | Coordinates from map click or manual entry |
| `longitude` | float | Yes | Coordinates from map click or manual entry |
| `incident_type` | string | Yes | Same enum as online reports |
| `description` | string | Yes | Narrative based on caller's narration |
| `severity` | string | Yes | `low`, `medium`, `high`, `critical` |
| `location_description` | string | No | Landmark or verbal location description |

**Auth level:** `admin`, `encoder`

**Request Body:**
```json
{
  "caller_name": null,
  "caller_contact": null,
  "is_anonymous": true,
  "latitude": 13.2845,
  "longitude": 123.3987,
  "incident_type": "vehicular_accident",
  "description": "Caller reports a motorcycle vs tricycle collision near Camal Public Market. Two injured.",
  "severity": "critical",
  "location_description": "Near the old market entrance, Camal Public Market"
}
```

**Response Body (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": 1043,
    "incident_number": "RQ-2025-1043",
    "status": "under_verification",
    "source": "caller_based",
    "is_anonymous": true,
    "latitude": 13.2845,
    "longitude": 123.3987,
    "incident_type": "vehicular_accident",
    "description": "Caller reports a motorcycle vs tricycle collision near Camal Public Market. Two injured.",
    "severity": "critical",
    "location_description": "Near the old market entrance, Camal Public Market",
    "reported_at": "2025-01-15T15:02:44+08:00",
    "encoded_by": { "id": 3, "name": "Maria Santos" }
  }
}
```

**Status Codes:** `201` Created · `403` Forbidden (not encoder/admin) · `422` Validation error (anonymous flag mismatch)

---

### Public Incident Map & Filtering

#### GET /api/v1/incidents/map

Returns verified incidents for the public map with optional filters. Only incidents with status `verified`, `ongoing`, or `resolved` are returned. Supports pagination.

**Query Parameters:**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `incident_type` | string | No | Filter by type (e.g., `fire`, `typhoon_flood`) |
| `status` | string | No | `verified`, `ongoing`, `resolved` |
| `source` | string | No | `online` or `caller_based` |
| `from` | datetime | No | Start datetime (ISO 8601) |
| `to` | datetime | No | End datetime (ISO 8601) |
| `page` | integer | No | Page number (default: 1) |

**Auth level:** Public (no token required)

**Response Body (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1042,
      "incident_number": "RQ-2025-1042",
      "incident_type": "typhoon_flood",
      "severity": "high",
      "status": "ongoing",
      "latitude": 13.2712,
      "longitude": 123.4121,
      "description": "Flooding along Camal riverside, water level rising rapidly near residential area.",
      "reported_at": "2025-01-15T14:32:10+08:00",
      "updated_at": "2025-01-15T16:00:00+08:00",
      "source": "online"
    },
    {
      "id": 1043,
      "incident_number": "RQ-2025-1043",
      "incident_type": "vehicular_accident",
      "severity": "critical",
      "status": "verified",
      "latitude": 13.2845,
      "longitude": 123.3987,
      "description": "Caller reports a motorcycle vs tricycle collision near Camal Public Market. Two injured.",
      "reported_at": "2025-01-15T15:02:44+08:00",
      "updated_at": "2025-01-15T15:10:00+08:00",
      "source": "caller_based"
    }
  ],
  "meta": {
    "current_page": 1,
    "last_page": 3,
    "per_page": 20,
    "total": 57
  }
}
```

**Status Codes:** `200` Success · `400` Invalid filter parameters

---

## Error Codes Summary

| HTTP Code | Meaning | Common Cause |
|---|---|---|
| `400` | Bad Request | Invalid coordinates, malformed query params |
| `401` | Unauthenticated | Missing or expired JWT token |
| `403` | Forbidden | Authenticated but insufficient role |
| `404` | Not Found | Resource ID does not exist |
| `409` | Conflict | State transition not allowed (e.g., verifying already-verified incident) |
| `422` | Unprocessable Entity | Validation failure on request body |
| `429` | Too Many Requests | Rate limit exceeded (100 req/min per user) |
| `500` | Server Error | Unexpected backend failure |

## Rate Limiting

- Public endpoints: 30 requests/minute per IP
- Authenticated endpoints: 100 requests/minute per user
- File upload endpoints: 10 requests/minute per user