# DESIGN.md: ResQHub

## 1. Design Read (Evidence-Based)

- **Product:** ResQHub — Community Emergency and Incident Reporting System for MDRRMO-Camal
- **Target Audience:** MDRRMO staff (admin, encoder/dispatcher), barangay officials, emergency responders, and registered community users in Camal municipality
- **Product Type:** Dashboard
- **Primary User Goal:** Quickly submit, verify, monitor, and resolve incident reports with geospatial context
- **User Roles & Workflows:**
  - **Community User:** Map-first incident submission → track own report status → view verified incidents and advisories
  - **Encoder/Dispatcher:** Encode caller reports (<90s) → verify/reject → assign responders → update status → post announcements
  - **Admin:** All encoder actions + user account management + analytics export
  - **Barangay Official / Responder:** View incident map, filters, and status updates (read-only for most data)
- **Brand / Aesthetic Direction:** Institutional, utilitarian, calm, map-centric, data-dense. The interface must communicate operational seriousness and trustworthiness for public safety. No decorative flourish; clarity and speed are the brand.
- **Key Personality Traits:** Authoritative, efficient, dependable

## 2. Design Dials (Context-Specific)

| Dial | Value | Rationale |
|---|---|---|
| DESIGN_VARIANCE | 3 | Strict data consistency is required. Incident records, statuses, and maps must look identical across sessions. Low variance ensures encoders develop muscle memory and the public map remains predictable. |
| MOTION_INTENSITY | 2 | High task velocity is critical during emergencies. Motion is restricted to opacity/transform transitions under 150ms for hover/selection feedback only. No decorative animation. |
| VISUAL_DENSITY | 8 | Operators need maximum information per viewport: incident lists, map markers, status chips, and filter controls must coexist. Dense tabular layouts and compact map overlays serve this need. |

## 3. Visual Identity & Product-Type Adaptation

This is a mission-critical dashboard. The design prioritizes:

- **Scanning:** Incident lists use a tabular master/detail layout with high typographic contrast for status and priority.
- **Data views:** The map is the primary data view, not a decorative element. Markers encode status via shape and color; the light-minimal OSM basemap keeps visual noise low.
- **Strong hierarchy:** Status colors are the single most salient visual signal. Typography uses weight and size, not color alone, to establish hierarchy.
- **Distinctiveness:** No gradients, no glassmorphism, no rounded "hero" cards. The interface is flat, uses hairline 1px borders, generous whitespace between data groups, and an 8px grid system. The map is the visual hero; the chrome around it is quiet and institutional.

## 4. Semantic Color System (Color Discipline)

Neutral colors form 90% of the interface. Semantic colors are reserved exclusively for status and actionable states.

```css
:root {
  --color-primary: #1B4D3E;        /* MDRRMO green — brand, active nav, primary buttons */
  --color-secondary: #4A6572;      /* Slate blue-gray — secondary actions, links */
  --color-accent: #C0392B;         /* Alert red — urgent CTAs, priority incidents */
  --color-success: #2E7D32;        /* Resolved/verified states */
  --color-warning: #F9A825;        /* Ongoing/pending states */
  --color-danger: #C62828;         /* Critical/closed-in-error states */
  --color-bg: #F5F6F7;             /* Page background — light gray */
  --color-surface: #FFFFFF;        /* Cards, panels, modals */
  --color-fg: #1A1C1E;             /* Primary text — near-black */
  --color-muted: #6B7280;          /* Secondary text, metadata */
  --color-border: #E0E2E5;         /* Hairline dividers, table borders */
}
```

**Usage rules:**

- `--color-primary`: Only for primary navigation, primary buttons (one per viewport), and active states.
- `--color-accent`: Only for "Submit Report" CTA and priority-1 incident markers. Never for decorative elements.
- `--color-success` / `--color-warning` / `--color-danger`: Status chips, map markers (with shape distinction), and progress indicators only.
- Neutrals (`--color-bg`, `--color-surface`, `--color-fg`, `--color-muted`, `--color-border`) constitute all backgrounds, text, and structural lines.

## 5. Typography & Type Scale (Typography Discipline)

**Font Family:** `IBM Plex Sans` (Google Fonts) for UI and `IBM Plex Mono` for coordinates, timestamps, and incident IDs. IBM Plex Sans offers strong legibility at small sizes with a slightly technical, institutional character that fits emergency operations. Mono is used for data that benefits from tabular alignment.

```html
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
```

| Level | Size | Weight | Line-Height | Tracking | Rationale |
|---|---|---|---|---|---|
| h1 (Page Title) | 1.5rem / 24px | 600 | 1.3 | -0.01em | Single page title per view; strong but not oversized |
| h2 (Section) | 1.25rem / 20px | 600 | 1.4 | -0.01em | Panel and section headers |
| h3 (Subsection) | 1.125rem / 18px | 600 | 1.4 | 0 | Card titles, form group headers |
| h4 (Widget Title) | 1rem / 16px | 600 | 1.5 | 0 | Map panel headers, widget titles |
| h5 / h6 | 0.875rem / 14px | 600 | 1.5 | 0 | Table column headers, list item titles |
| Body | 0.875rem / 14px | 400 | 1.6 | 0 | Primary reading text, form inputs |
| Caption | 0.75rem / 12px | 400 | 1.5 | 0.01em | Metadata, timestamps, helper text |
| Mono (Data) | 0.8125rem / 13px | 400 | 1.5 | 0 | Coordinates, IDs, timestamps |

## 6. Layout Strategy & Anti-Repetition Rules

**Structural Layout Patterns (by view):**

- **Public Incident Map:** Full-bleed map (75% width) + right-side collapsible filter panel (25% width). No card wrapping around the map.
- **Incident Submission (Online):** Two-column form: left = map picker (60%), right = incident details form (40%). The map is the first interactive element.
- **Encoder Caller Report:** Split-pane: left = form fields for caller info and narrative (50%), right = map for location tagging (50%). Form flows top-to-bottom in a single column.
- **Admin Dashboard:** Master/detail: left = filterable incident table (55%), right = selected incident detail panel (45%). Table rows are separated by hairlines, not cards.
- **Reports & Analytics:** Tabular data with a top filter bar. Charts (bar/line) appear inline between table sections, not in separate card grids.

**Anti-Repetition Rules:** No "Hero → 3 Cards" pattern anywhere. No two consecutive views use the same layout structure. The public map, submission form, encoder pane, and admin table each have distinct compositions.

**Grid & Spacing:** Base unit = 8px. Page gutters = 24px (desktop), 16px (tablet), 12px (mobile). Column gaps = 16px. Section margins = 32px. Table cell padding = 12px vertical / 16px horizontal.

## 7. Anti-AI-Slop Rules (Avoid vs. Prefer)

- **Avoid:** Generic three-card feature grids. → **Prefer:** Content-based structures: split-pane forms, master/detail tables, full-bleed maps.
- **Avoid:** Every section wrapped in rounded cards. → **Prefer:** Separation via whitespace, hairline `--color-border` dividers, and grid alignment. Cards only for dashboard widgets and modals.
- **Avoid:** Purple/blue AI gradients or glowing mesh blobs. → **Prefer:** Flat neutral `--color-bg` with sparse, high-contrast semantic accents (`--color-primary`, `--color-danger`).
- **Avoid:** Decorative icons, badges, abstract shapes. → **Prefer:** Direct typographic hierarchy, status labels (e.g., "VERIFIED", "ONGOING"), and functional map markers.
- **Avoid:** Layout-heavy animation or decorative movement. → **Prefer:** Opacity/transform transitions under 150ms for hover and selection feedback only.

## 8. Card & Container Discipline

**Cards are allowed for:**

- Dashboard summary widgets (e.g., "Incidents Today", "Pending Verification")
- Modal dialogs (incident detail popup on map)
- Draggable map legend panel

**Cards are forbidden for:**

- Standard text sections, paragraphs, or static content
- Lists (use hairline-separated rows)
- Form fields (use flat inputs with bottom borders or contained fields directly on the surface)
- Table rows (use full-width rows with `--color-border` dividers)

**No card nesting.** A card may contain form elements or lists, but never another card container.

## 9. Component Rules & Action Hierarchy

**Button Tiers:**

| Tier | Style | Contrast | Usage |
|---|---|---|---|
| Primary | `--color-primary` bg, white text | 4.5:1+ | One per viewport: "Submit Report", "Verify Incident", "Save Report" |
| Secondary | White bg, `--color-primary` border/text | 4.5:1+ | "Cancel", "Export", "Assign Responder" |
| Tertiary | Text-only, `--color-secondary` | 4.5:1+ | "View Details", "Edit", "Retry" |

**State Visuals:**

- **Hover:** Slight background change (`--color-border` tint) or 1px border darkening. No scale/transform.
- **Focus:** 2px solid `--color-primary` outline, 2px offset from element. Never removed.
- **Disabled:** 40% opacity, no hover effect, cursor `not-allowed`.
- **Selected:** `--color-primary` background for active filters/nav; checked radio/checkbox uses `--color-primary`.
- **Active (pressed):** Background darkens by 10% (e.g., `#14382D` for primary).

## 10. Behavioral Responsive Design

| Breakpoint | Behavior |
|---|---|
| Desktop (≥1024px) | Full layouts as described in Section 6. Master/detail side-by-side. |
| Tablet (768–1023px) | Master/detail stacks vertically: table on top (60vh), detail panel below. Map views remain full-width with filter panel collapsing to a slide-over drawer. Form columns stack to single column. |
| Mobile (<768px) | Top nav collapses to hamburger. Filter panel becomes bottom sheet. Tables hide secondary columns (source, timestamp) — accessible via row tap → detail. Desktop top nav becomes bottom tab bar: Map, Report, Alerts, Profile. Submit button becomes a fixed bottom-right floating action (still one dominant action). |

## 11. States (Loading, Empty, Error)

**Loading State:** Skeleton loaders matching actual container shapes. Map area shows a flat gray `--color-bg` rectangle with a centered "Loading map…" text. Table rows show 3 skeleton lines each. No spinning spinners.

**Empty State:**

- **Incident list:** "No incidents match the current filters." + buttons: "Clear Filters" (secondary) and "Submit a Report" (primary).
- **Map with no markers:** "No verified incidents in this area." + "Adjust filters" link.
- **Announcements:** "No active advisories. Check back during weather events."

**Error State:**

- **Form submission failure:** Inline alert banner at top of form: "Report could not be saved. Check your connection and try again." + "Retry" button (tertiary). Form data is preserved.
- **Map tile load failure:** Map area shows flat `--color-bg` with message: "Map unavailable. Coordinates are still captured." + "Reload Map" button.
- **API failure on list views:** Full-width alert: "Unable to load incident data." + "Retry" button. No partial data shown.

## 12. Accessibility & Inclusivity (WCAG 2.1 AA)

- **Keyboard Navigation:** All interactive elements reachable via Tab in logical DOM order. Map markers focusable; Enter/Space opens detail popup. Escape closes modals, drawers, and popups.
- **Focus Rings:** Minimum 2px solid `--color-primary` outline with 2px offset on all focusable elements. Never suppressed.
- **ARIA Roles:** Map container has `role="application"` with `aria-label="Incident map"`. Markers have `role="button"` and `aria-label="Incident [ID], [type], [status]"`. Status chips use `role="status"`. Form errors use `aria-live="assertive"`.
- **Touch Targets:** All buttons, links, and markers ≥ 44×44px. Inline text links have 44px min hit area via padding.
- **Color Independence:** Status always communicated via text label + color + shape (e.g., verified = green circle, ongoing = amber triangle, resolved = green square). Never color alone.
- **Contrast:** All text meets 4.5:1 minimum; large text (≥18px) meets 3:1. `--color-muted` text is 4.5:1 against `--color-bg` and `--color-surface`.

## 13. Design Rationale

The design system is built for operational speed and trust. The map-first submission flow (FR-01) dictates the split-pane layout: users pick a location before typing details, so the map is always the dominant visual element. The manual verification workflow (FR-07) requires a clear status system — the semantic color palette and shape-coded markers make "Under Verification" vs. "Verified" instantly distinguishable at a glance. The encoder's 90-second caller report target (NFR) demands a dense, single-column form with the map adjacent, not below. The institutional, utilitarian aesthetic (flat neutrals, hairline borders, IBM Plex Sans) signals government-grade reliability, discouraging casual or false reports by making the system feel official. Low motion intensity and high visual density ensure operators process incidents without distraction, directly supporting the 15-minute verification KPI.

## 14. NO Invented Design Content Rule

All content must derive from the PRD scope. Placeholder text is limited to: "Incident Type", "Description", "Caller Name", "Contact Number", "Coordinates". No fake testimonials, no invented user logos, no fabricated statistics. Mock data for design review must be generated from the incident taxonomy in the PRD (typhoon, flood, earthquake, landslide, vehicular accident, fire, drowning, hazmat, EMS) and realistic Camal barangay names. No abstract decorative imagery may be introduced.

## 15. Design Pre-Flight Checklist

- [x] Design is derived from PRD/project context.
- [x] Design Read is specific.
- [x] Design dials are intentional.
- [x] Visual direction is justified.
- [x] Color hierarchy is intentional.
- [x] Typography is intentional.
- [x] Cards are not overused.
- [x] Layouts are not repetitive.
- [x] No generic AI aesthetic was introduced without justification.
- [x] Motion has a purpose.
- [x] Responsive behavior is defined.
- [x] Loading states are defined where relevant.
- [x] Empty states are defined where relevant.
- [x] Error states are defined where relevant.
- [x] Accessibility is defined.
- [x] No fake content was invented.
- [x] Design feels specific to the product.
- [x] A coding agent can implement the design without inventing major visual decisions.
- [x] Design System is cohesive and reusable.