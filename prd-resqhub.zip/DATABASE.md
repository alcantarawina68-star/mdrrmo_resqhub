# DATABASE.md: ResQHub

## ERD

```mermaid
erDiagram
    USERS {
        Int id PK
        String name
        String email
        String password_hash
        String role
        String contact_number
        String barangay
        String status
        DateTime created_at
        DateTime updated_at
    }

    INCIDENTS {
        Int id PK
        Int user_id FK
        String incident_type
        String description
        Decimal latitude
        Decimal longitude
        String location_label
        String source
        String caller_name
        String caller_contact
        Boolean is_anonymous
        String status
        String priority
        String assigned_unit
        DateTime reported_at
        DateTime verified_at
        DateTime resolved_at
        DateTime created_at
        DateTime updated_at
    }

    EVIDENCE {
        Int id PK
        Int incident_id FK
        String file_path
        String file_type
        String original_name
        Int file_size
        DateTime uploaded_at
    }

    STATUS_LOGS {
        Int id PK
        Int incident_id FK
        Int user_id FK
        String old_status
        String new_status
        String note
        DateTime created_at
    }

    ANNOUNCEMENTS {
        Int id PK
        Int user_id FK
        String title
        String content
        String category
        String severity
        DateTime published_at
        DateTime expires_at
        DateTime created_at
        DateTime updated_at
    }

    USERS ||--o{ INCIDENTS : submits
    USERS ||--o{ STATUS_LOGS : performs
    USERS ||--o{ ANNOUNCEMENTS : publishes
    INCIDENTS ||--o{ EVIDENCE : contains
    INCIDENTS ||--o{ STATUS_LOGS : tracks
```

## Table Definitions

### users

| Column | Type | Constraints | Index |
|:---|:---|:---|:---|
| id | INT UNSIGNED | PK, AUTO_INCREMENT | PK |
| name | VARCHAR(120) | NOT NULL | |
| email | VARCHAR(190) | NOT NULL, UNIQUE | UK_email |
| password_hash | VARCHAR(255) | NOT NULL | |
| role | ENUM('admin','encoder','barangay_official','responder','community_user') | NOT NULL, DEFAULT 'community_user' | IDX_role |
| contact_number | VARCHAR(20) | NULL | |
| barangay | VARCHAR(100) | NULL | |
| status | ENUM('active','inactive','suspended') | NOT NULL, DEFAULT 'active' | |
| created_at | TIMESTAMP | NOT NULL, DEFAULT CURRENT_TIMESTAMP | |
| updated_at | TIMESTAMP | NOT NULL, DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | |

### incidents

| Column | Type | Constraints | Index |
|:---|:---|:---|:---|
| id | INT UNSIGNED | PK, AUTO_INCREMENT | PK |
| user_id | INT UNSIGNED | FK → users.id, NOT NULL | IDX_user |
| incident_type | ENUM('typhoon_flood','earthquake','landslide','vehicular_accident','fire','drowning','hazmat','ems','patient_transport','other') | NOT NULL | IDX_type |
| description | TEXT | NOT NULL | |
| latitude | DECIMAL(10,7) | NOT NULL | IDX_coords |
| longitude | DECIMAL(10,7) | NOT NULL | IDX_coords |
| location_label | VARCHAR(255) | NULL | |
| source | ENUM('online','caller_based') | NOT NULL | IDX_source |
| caller_name | VARCHAR(120) | NULL | |
| caller_contact | VARCHAR(20) | NULL | |
| is_anonymous | BOOLEAN | NOT NULL, DEFAULT FALSE | |
| status | ENUM('new','under_verification','verified','ongoing','resolved','closed','rejected') | NOT NULL, DEFAULT 'under_verification' | IDX_status |
| priority | ENUM('low','medium','high','urgent') | NOT NULL, DEFAULT 'medium' | |
| assigned_unit | VARCHAR(120) | NULL | |
| reported_at | TIMESTAMP | NOT NULL, DEFAULT CURRENT_TIMESTAMP | IDX_reported |
| verified_at | TIMESTAMP | NULL | |
| resolved_at | TIMESTAMP | NULL | |
| created_at | TIMESTAMP | NOT NULL, DEFAULT CURRENT_TIMESTAMP | |
| updated_at | TIMESTAMP | NOT NULL, DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | |

### evidence

| Column | Type | Constraints | Index |
|:---|:---|:---|:---|
| id | INT UNSIGNED | PK, AUTO_INCREMENT | PK |
| incident_id | INT UNSIGNED | FK → incidents.id, NOT NULL, ON DELETE CASCADE | IDX_incident |
| file_path | VARCHAR(255) | NOT NULL | |
| file_type | VARCHAR(50) | NOT NULL | |
| original_name | VARCHAR(255) | NOT NULL | |
| file_size | INT UNSIGNED | NOT NULL | |
| uploaded_at | TIMESTAMP | NOT NULL, DEFAULT CURRENT_TIMESTAMP | |

### status_logs

| Column | Type | Constraints | Index |
|:---|:---|:---|:---|
| id | INT UNSIGNED | PK, AUTO_INCREMENT | PK |
| incident_id | INT UNSIGNED | FK → incidents.id, NOT NULL, ON DELETE CASCADE | IDX_incident |
| user_id | INT UNSIGNED | FK → users.id, NOT NULL | |
| old_status | VARCHAR(30) | NOT NULL | |
| new_status | VARCHAR(30) | NOT NULL | |
| note | TEXT | NULL | |
| created_at | TIMESTAMP | NOT NULL, DEFAULT CURRENT_TIMESTAMP | |

### announcements

| Column | Type | Constraints | Index |
|:---|:---|:---|:---|
| id | INT UNSIGNED | PK, AUTO_INCREMENT | PK |
| user_id | INT UNSIGNED | FK → users.id, NOT NULL | |
| title | VARCHAR(200) | NOT NULL | |
| content | TEXT | NOT NULL | |
| category | ENUM('advisory','warning','safety_info','incident_update') | NOT NULL | |
| severity | ENUM('info','caution','urgent') | NOT NULL, DEFAULT 'info' | |
| published_at | TIMESTAMP | NOT NULL, DEFAULT CURRENT_TIMESTAMP | IDX_published |
| expires_at | TIMESTAMP | NULL | |
| created_at | TIMESTAMP | NOT NULL, DEFAULT CURRENT_TIMESTAMP | |
| updated_at | TIMESTAMP | NOT NULL, DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | |

## Prisma Schema

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "mysql"
  url      = env("DATABASE_URL")
}

enum Role {
  admin
  encoder
  barangay_official
  responder
  community_user
}

enum UserStatus {
  active
  inactive
  suspended
}

enum IncidentType {
  typhoon_flood
  earthquake
  landslide
  vehicular_accident
  fire
  drowning
  hazmat
  ems
  patient_transport
  other
}

enum IncidentSource {
  online
  caller_based
}

enum IncidentStatus {
  new
  under_verification
  verified
  ongoing
  resolved
  closed
  rejected
}

enum Priority {
  low
  medium
  high
  urgent
}

enum AnnouncementCategory {
  advisory
  warning
  safety_info
  incident_update
}

enum Severity {
  info
  caution
  urgent
}

model User {
  id            Int        @id @default(autoincrement())
  name          String     @db.VarChar(120)
  email         String     @unique @db.VarChar(190)
  passwordHash  String     @map("password_hash") @db.VarChar(255)
  role          Role       @default(community_user)
  contactNumber String?    @map("contact_number") @db.VarChar(20)
  barangay      String?    @db.VarChar(100)
  status        UserStatus @default(active)
  createdAt     DateTime   @default(now()) @map("created_at")
  updatedAt     DateTime   @updatedAt @map("updated_at")

  incidents     Incident[]
  statusLogs    StatusLog[]
  announcements Announcement[]

  @@index([role])
  @@map("users")
}

model Incident {
  id            Int            @id @default(autoincrement())
  userId        Int            @map("user_id")
  incidentType  IncidentType   @map("incident_type")
  description   String         @db.Text
  latitude      Decimal        @db.Decimal(10, 7)
  longitude     Decimal        @db.Decimal(10, 7)
  locationLabel String?        @map("location_label") @db.VarChar(255)
  source        IncidentSource
  callerName    String?        @map("caller_name") @db.VarChar(120)
  callerContact String?        @map("caller_contact") @db.VarChar(20)
  isAnonymous   Boolean        @default(false) @map("is_anonymous")
  status        IncidentStatus @default(under_verification)
  priority      Priority       @default(medium)
  assignedUnit  String?        @map("assigned_unit") @db.VarChar(120)
  reportedAt    DateTime       @default(now()) @map("reported_at")
  verifiedAt    DateTime?      @map("verified_at")
  resolvedAt    DateTime?      @map("resolved_at")
  createdAt     DateTime       @default(now()) @map("created_at")
  updatedAt     DateTime       @updatedAt @map("updated_at")

  user         User          @relation(fields: [userId], references: [id])
  evidence     Evidence[]
  statusLogs   StatusLog[]

  @@index([userId])
  @@index([incidentType])
  @@index([status])
  @@index([source])
  @@index([reportedAt])
  @@index([latitude, longitude])
  @@map("incidents")
}

model Evidence {
  id           Int      @id @default(autoincrement())
  incidentId   Int      @map("incident_id")
  filePath     String   @map("file_path") @db.VarChar(255)
  fileType     String   @map("file_type") @db.VarChar(50)
  originalName String   @map("original_name") @db.VarChar(255)
  fileSize     Int      @map("file_size")
  uploadedAt   DateTime @default(now()) @map("uploaded_at")

  incident Incident @relation(fields: [incidentId], references: [id], onDelete: Cascade)

  @@index([incidentId])
  @@map("evidence")
}

model StatusLog {
  id         Int      @id @default(autoincrement())
  incidentId Int      @map("incident_id")
  userId     Int      @map("user_id")
  oldStatus  String   @map("old_status") @db.VarChar(30)
  newStatus  String   @map("new_status") @db.VarChar(30)
  note       String?  @db.Text
  createdAt  DateTime @default(now()) @map("created_at")

  incident Incident @relation(fields: [incidentId], references: [id], onDelete: Cascade)
  user     User     @relation(fields: [userId], references: [id])

  @@index([incidentId])
  @@map("status_logs")
}

model Announcement {
  id          Int                  @id @default(autoincrement())
  userId      Int                  @map("user_id")
  title       String               @db.VarChar(200)
  content     String               @db.Text
  category    AnnouncementCategory
  severity    Severity             @default(info)
  publishedAt DateTime             @default(now()) @map("published_at")
  expiresAt   DateTime?            @map("expires_at")
  createdAt   DateTime             @default(now()) @map("created_at")
  updatedAt   DateTime             @updatedAt @map("updated_at")

  user User @relation(fields: [userId], references: [id])

  @@index([publishedAt])
  @@map("announcements")
}
```

## Raw SQL Migrations

### Partial unique index for active user email (only when status is active)

```sql
CREATE UNIQUE INDEX users_active_email_unique ON users (email) WHERE status = 'active';
```

Note: This partial index is not representable in Prisma schema syntax. Apply via raw SQL migration after `prisma migrate dev` generates the base schema.