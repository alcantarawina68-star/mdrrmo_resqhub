# PRD: ResQHub

## Executive Summary & Product Vision
ResQHub is a web-based community emergency and incident reporting information system for MDRRMO-Camal. It unifies online reports from registered community users and phone-call reports encoded by authorized personnel into one centralized monitoring dashboard. The system supports map-first incident submission, manual verification, SMS notifications, real-time status tracking, public advisories, and analytical reporting for LGU decision-making.

Key product decisions:
- **Report flow:** Quick map-first submission—user picks incident location on a map before entering incident details.
- **Verification process:** Manual review by MDRRMO encoder/dispatcher before public visibility.
- **Notification channels:** SMS alerts for new incidents, assignments, and urgent priority events.
- **Map visual style:** Light minimal basemap with clean incident markers.
- **Report anonymity:** Online reports require registration; caller-based reports may be recorded as anonymous but are encoded by authorized staff.

## Problem Statement & Target Users
MDRRMO-Camal currently handles emergency reports through phone calls, paper logs, and scattered digital channels. There is no unified system for tracking incidents from initial report to resolution, no geospatial visualization of incident locations, and no verified public advisory dissemination.

Target users:
- MDRRMO Administrator
- Encoder / Dispatcher
- Barangay Official
- Emergency Responder (MDRRMO, BFP, EMS, rescue)
- Registered Community User

## System Scope & User Roles

| Capability | Admin | Encoder/Dispatcher | Barangay Official | Responder | Community User |
|---|---|---|---|---|---|
| Submit online incident report | Yes | Yes | Yes | Yes | Yes |
| Encode caller-based report | Yes | Yes | No | No | No |
| Verify / reject incident | Yes | Yes | No | No | No |
| Assign responders / units | Yes | Yes | View only | No | No |
| Update incident status | Yes | Yes | Limited | Limited | No |
| Post emergency announcements | Yes | Yes | No | No | No |
| View incident map with filters | Yes | Yes | Yes | Yes | Yes |
| Manage user accounts | Yes | No | No | No | No |
| Export analytics reports | Yes | View only | No | No | No |

## Functional Requirements

### User-Facing
- **FR-01:** Registered community users must be able to submit an incident report using a map-first flow; the map loads immediately, and clicking a location sets latitude/longitude before incident type, description, and evidence upload.
- **FR-02:** The online incident form must support automatic timestamp capture, geolocation tagging, incident type selection from MDRRMO categories (typhoon/flood, earthquake, landslide, vehicular accident, fire, drowning, hazmat, EMS, etc.), and optional image or document evidence.
- **FR-03:** Users must be able to view only verified incident markers on the public light-minimal map, filterable by incident type, date/time, status, and report source (Online / Caller-Based).
- **FR-04:** Users must be able to view official emergency announcements, advisories, safety information, and verified incident updates posted by MDRRMO.
- **FR-05:** A reporting user must be able to track the status of their own submitted incident from New/Under Verification to Verified, Ongoing, Resolved, or Closed.

### Admin-Facing
- **FR-06:** Encoders/dispatchers must be able to manually encode caller-based incident reports, including caller name, contact number, optional anonymous flag, incident narrative, location tag via map click or manual coordinates, and mark source as “Caller-Based”.
- **FR-07:** The system must enforce manual review: all online and caller reports enter as “Under Verification” and are hidden from public map until an admin or encoder validates them.
- **FR-08:** Authorized personnel must be able to change incident status (New, Verified, Ongoing, Resolved, Closed), add response notes, and assign responsible MDRRMO units or specific responders.
- **FR-09:** Administrators must be able to create, edit, and deactivate user accounts; assign roles; and control account status.
- **FR-10:** The system must generate internal summary and statistical reports by source, type, time, location, and response time, with export capability for LGU documentation.
- **FR-11:** SMS notifications must be triggered for: new caller-based and online reports to on-duty MDRRMO personnel, assignment alerts to responders, status changes to concerned parties, and priority alerts for urgent verified incidents.

## Non-Functional Requirements

| Category | Target |
|---|---|
| Performance | Map renders within 2s on 4G; incident submission saved in under 3s; status updates immediate. |
| Availability | 99.5% uptime during non-calamity periods; graceful degradation of map when OSM tiles slow. |
| Security | JWT-based auth; role-based access control; all inputs validated; files scanned; HTTPS enforced. |
| Scalability | Support 1,000 registered users and 500 concurrent incident reports per municipality without degradation. |
| Data retention | Incident records retained indefinitely for LGU audit; evidence files stored securely with backup. |
| Usability | Encoder can complete caller report in under 90 seconds; community report under 2 minutes after login. |
| SMS reliability | SMS delivery attempt logged; failure retried once; alternate on-screen notification fallback. |

## Technology Stack & Rationale

| Component | Technology | Why |
|---|---|---|
| Frontend | Vue.js with Nuxt | Reactive SSR for fast map-centric UI; component reuse for incident forms and admin dashboards. |
| Backend | Laravel (PHP) | Robust API, queue jobs for SMS, role/permission packages, rapid development for LGU use. |
| Database | MySQL | Proven relational storage for incidents, users, logs, and reports; ACID compliance. |
| Auth | JWT-based Auth | Stateless API authentication across Vercel frontend and Railway backend. |
| Mapping | Leaflet with OpenStreetMap | Lightweight, open-source, no API key cost; supports light-minimal tiles and custom markers. |
| Hosting | Vercel + Railway | Vercel for Nuxt frontend CDN; Railway for Laravel API and MySQL; easy scaling for municipal deployment. |

## Success Metrics & KPIs

| Metric | Target |
|---|---|
| Average online incident submission time (login to saved) | ≤ 2 minutes |
| Average caller report encoding time | ≤ 90 seconds |
| Percentage of incidents verified within 15 minutes | ≥ 80% |
| SMS notification delivery success rate | ≥ 95% |
| Monthly active registered community users | ≥ 300 |
| Percentage of incidents with valid coordinates | 100% |
| Number of exported LGU reports per month | ≥ 4 |
| Map load time on budget smartphone | ≤ 2.5 seconds |

## Risk Analysis & Mitigation

| Risk | Impact | Mitigation Strategy |
|---|---|---|
| False or malicious online reports | Wasted responder time, public panic | Manual verification required before public map; user account tied to report; disable accounts that abuse. |
| SMS gateway outage or delay | Missed dispatch alerts | Log all SMS attempts; retry once; keep in-app notification center; allow manual send. |
| Inaccurate location from caller reports | Wrong dispatch location | Encoder must confirm location via map click or known landmark; use distance validation; allow correction after initial entry. |
| Hosting downtime on Railway backend | Incident submission unavailable | Use queue-based writes; status page; local offline fallback not in v1 but ensure APIs degrade gracefully. |
| Privacy breach of caller data | Legal and community trust loss | Role-based access to caller PII; anonymous option for caller; audit logs; encrypt sensitive fields. |
| Low adoption by community users | System underutilized | Public advisories encourage registration; SMS vs online training with barangay officials; simple map-first UI. |

## Constraints & Assumptions

**Constraints:**
- Web-based only; no native mobile app in this version.
- Online incident reports require verified user registration.
- Caller-based reports must be encoded by authorized MDRRMO personnel.
- SMS notifications depend on a third-party SMS provider with Philippine mobile support.
- Deployed for MDRRMO-Camal only; not yet multi-tenant.

**Assumptions:**
- Responders and barangay officials have smartphone internet access.
- OpenStreetMap has sufficient coverage for Camal area.
- MDRRMO staff will receive basic training for encoder and admin roles.
- LGU will provide municipal server/backup and SMS gateway credentials.

## Out of Scope
- Native iOS/Android mobile application.
- Automated AI-based incident verification or classification.
- Two-way SMS conversation with responders.
- Multi-LGU or regional deployment.
- Offline-first functionality or local caching of incident creation.
- Automated dispatch routing algorithms (e.g., nearest responder optimization).
- Social media integration for posting advisories.
- Public anonymous online reporting (anonymous only allowed for caller-based reports encoded by staff).
- Real-time live tracking of responder vehicles.
- Integration with external CAD or BFP systems.